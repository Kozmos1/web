function populateAllTable(){
    //Get table from the json file
    fetch('Tables/movies.json')
    .then(response => response.json())
    .then(function(json) {

      //get the table body HTML element
      var tablebody = document.getElementById("MovieTableBody")
      
      //prepare the table body
      tablebody.innerHTML = "";

      //create an entry in the html table for each movie in the json table
      json.movies.forEach(function(movie) {
        console.log("for loop is running")
        var tr = document.createElement("tr");
        tr.innerHTML = 
        "<td>" + movie.Title + "</td>" +
        "<td>" + movie.Cast + "</td>" +
        "<td>" + movie.ReleaseDate + "</td>" + 
        "<td>" + movie.Series + "</td>";
        tablebody.appendChild(tr);
      });
    });
};




function search(){
  //Get the necessary HTML elements
  var searchbar = document.getElementById("searchbar");
  var table = document.getElementById("MoviesTable");
  var tablebody = document.getElementById("MovieTableBody");

  //Makes sure that the search bar isn't empty
  if(searchbar.value){

    //Accesses the movies table
    fetch('Tables/movies.json')
    .then(response => response.json())
    .then(function(json) {

      //prepares the table body
      tablebody.innerHTML = "";
       
      //Checks each movie in the table
      json.movies.forEach(function(movie) {
        console.log("for loop is running")
        
        //If the title matches the search term add its information to the table body
        if(movie.Title.toLowerCase().includes(searchbar.value.toLowerCase())){
          var tr = document.createElement("tr");
          tr.innerHTML = 
          "<td>" + movie.Title + "</td>" +
          "<td>" + movie.Cast + "</td>" +
          "<td>" + movie.ReleaseDate + "</td>" + 
          "<td>" + movie.Series + "</td>";
          tablebody.appendChild(tr);
        }

        //Otherwise if the cast matches the search term add its information to the table body
        else if(movie.Cast.toLowerCase().includes(searchbar.value.toLowerCase())){
          var tr = document.createElement("tr");
          tr.innerHTML = 
          "<td>" + movie.Title + "</td>" +
          "<td>" + movie.Cast + "</td>" +
          "<td>" + movie.ReleaseDate + "</td>" + 
          "<td>" + movie.Series + "</td>";
          tablebody.appendChild(tr);
        }

        //Otherwise if the release date matches the search term add its information to the table body
        else if(movie.ReleaseDate.toLowerCase().includes(searchbar.value.toLowerCase())){
          var tr = document.createElement("tr");
          tr.innerHTML = 
          "<td>" + movie.Title + "</td>" +
          "<td>" + movie.Cast + "</td>" +
          "<td>" + movie.ReleaseDate + "</td>" + 
          "<td>" + movie.Series + "</td>";
          tablebody.appendChild(tr);
        }

        //Otherwise if the series matches the search term add its information to the table body
        else if(movie.Series.toLowerCase().includes(searchbar.value.toLowerCase())){
          var tr = document.createElement("tr");
          tr.innerHTML = 
          "<td>" + movie.Title + "</td>" +
          "<td>" + movie.Cast + "</td>" +
          "<td>" + movie.ReleaseDate + "</td>" + 
          "<td>" + movie.Series + "</td>";
          tablebody.appendChild(tr);
        }
      });
    });
  }

  //If there is no search term, populate the table normally
  else{
    populateAllTable();
  }         
};



function faveFilm() {
  //Gets the users answers
  var q1 = document.getElementById("Question1Select").value;
  var q2 = document.getElementById("Question2Select").value;
  var q3 = document.getElementById("Question3Select").value;

  //Chooses a film recommendation based off of the users answers
  var favefilmID;
  if (q1 == 3 & q2 == 1 & q3 == 1) {
    favefilmID = 1;//The Phantom Menace
  }
  else if (q1 == 1 & q2 == 3 & q3 == 2) {
    favefilmID = 2;//Attack of the clones
  }
  else if (q1 == 2 & q2 == 2 & q3 == 3) {
    favefilmID = 3;//Revenge of the Sith
  }
  else if (q1 == 3 & q2 == 1 & q3 == 2) {
    favefilmID = 4;//A New Hope
  }
  else if (q1 == 1 & q2 == 2 & q3 == 1) {
    favefilmID = 5;//The Empire Strikes Back
  }
  else if (q1 == 2 & q2 == 1 & q3 == 2) {
    favefilmID = 6;//Return of the Jedi
  }
  else if (q1 == 2 & q2 == 1 & q3 == 1) {
    favefilmID = 7;//The Force Awakens
  }
  else if (q1 == 2 & q2 == 3 & q3 == 2) {
    favefilmID = 10;//Rogue One
  }
  else if (q1 == 2 & q2 == 1 & q3 == 3) {
    favefilmID = 11;//Solo
  }
  else {
    favefilmID = 3;//Revenge of the Sith
  }
  console.log("Chosen movie ID", favefilmID)
  
  //gets the target HTML element
  var targetTag = document.getElementById("faveFilmTarget");

  //Accesses the movie table
  fetch('Tables/movies.json')
  .then(response => response.json())
  .then(function(json) {
    
    //Finds the movie with the matching ID
    json.movies.forEach(function(movie) {
      console.log("for loop is running")
      console.log(movie.ID, "?")

      //If a matching ID is find, fill the target HTML element with it's information
      if (movie.ID == favefilmID){
        console.log("if = true");
        document.getElementById("recImage").src = movie.Image;
        document.getElementById("recTitle").textContent = movie.Title;
        document.getElementById("recSeries").textContent = movie.Series;
        document.getElementById("recSynopsis").textContent = movie.Synopsis;
        //Originally we designed it so it would just add it at the bottom, but that was wasting space as the user had to scroll.
        //targetTag.innerHTML = 
        //"<img height='600' width='350' src='" + movie.Image + "' style='float: right; margin-right: 450px;'>" +
        //"<p style='margin-left: 1050px;'>" + movie.Title + "</p><br>" +
        //"<p style='margin-left: 1050px;'>" + movie.Series + "</p><br>" +
        //"<p style='margin-left: 1050px;'>" + movie.Synopsis + "</p><br>";
        console.log(movie.Synopsis);
      }
    });
  });
}


function User() {//This function generates a custom welcome message for the user
  var q1, q2;
  var name = document.getElementById("name").value;
  var force = document.getElementById("force").value;
  var radios = document.getElementsByName("1fan");
  for (var i = 0, length = radios.length; i < length; i++) {
    if (radios[i].checked) {
      var fan1chosen = i;
      break;
    }
  }
  var radios1 = document.getElementsByName("2fan");
  for (var i = 0, length = radios1.length; i < length; i++) {
    if (radios1[i].checked) {
      var fan2chosen = i;
      break;
    }//This was a HUGE PAIN. I spent 5 hours figuring this bit out as you can't just call which radio button is checked
  }//This is what it was, I've left it in so that you can see what I was trying to do
  //if (document.querySelector('input[name="1fan"]:checked').value == "yes" & document.querySelector('input[id="2fan"]:checked').value == "sky") {
  //  var descriptor = "a bad liar.";
  //}
  //else if (document.querySelector('input[name="1fan"]:checked').value == "yes" & document.querySelector('input[id="2fan"]:checked').value == "palp") {
  //  var descriptor = "strong and wise, and I am very proud of you.";
  //}
  //else if (document.querySelector('input[name="1fan"]:checked').value == "no") {
  //  var descriptor = "in the right place to join the greatest franchise.";
  //}
  //else {
  //  var descriptor = "going to have to start watching more Star Wars...";
  //}
  if (fan1chosen == 0 & fan2chosen == 0) {//Depending on the user's choice, 1 of four messages will appear.
    var descriptor = "a bad liar.";
  }
  else if (fan1chosen == 0 & fan2chosen == 1) {
    var descriptor = "strong and wise, and I am very proud of you.";
  }
  else if (fan1chosen == 1) {
    var descriptor = "in the right place to join the greatest franchise.";
  }
  else {
    var descriptor = "going to have to start watching more Star Wars...";
  }
  var box = document.getElementById("welcomeText");//Alongside the choices, their name and title will appear too.
  box.innerHTML = "Welcome, " + name + ", " + force + ", to our website. You are " + descriptor;
  //document.getElementById("welcomeText").textContent = ("Welcome, " + name + ", " + force + ", to our website. You are " + descriptor);
  //$("#welcomeText").load("#welcomeText");
  //document.getElementById("welcomeText").textContent = document.querySelector('input[id="1fan"]:checked').value;
}